package com.redhat.delayinit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DelayInitApplicationTests {

	@Test
	void contextLoads() {
	}

}
