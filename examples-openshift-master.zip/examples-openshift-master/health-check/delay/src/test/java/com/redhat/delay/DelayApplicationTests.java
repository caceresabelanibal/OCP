package com.redhat.delay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DelayApplicationTests {

	@Test
	void contextLoads() {
	}

}
