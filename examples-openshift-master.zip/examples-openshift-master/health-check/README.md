## Ejemplos de Health Check

- [Ejemplo básico](./delay)
- [Ejemplo comunicación entre servicios](./integration)
